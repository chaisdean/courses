from django.contrib.messages import error
from .models import Course
from django.shortcuts import render, redirect, HttpResponse
#from .models import Course

# Create your views here.
def index(request):
    content = {
        "courses": Course.objects.all()
    }
    return render(request, 'ccourse/index.html', content)

def create(request):
    errors = Course.objects.validate(request.POST)
    if errors:
        for i in errors:
            error(request, i)
    else:
        Course.objects.create(
            name = request.POST['name'],
            desc = request.POST['desc']
        )
    return redirect('/')


def confirm(request, course_id):
    content = {
        "course": Course.objects.get(id=course_id)
    }
    return render(request, 'ccourse/confirm.html', content)

def delete(request, course_id):
    Course.objects.get(id=course_id).delete()
    return redirect('/')
